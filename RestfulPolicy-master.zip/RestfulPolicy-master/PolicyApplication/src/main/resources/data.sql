insert into policy values (10001, 10000.00, '2018-08-01', 'Nathan', 'Penny', '2018-07-29');
insert into policy values (10002, 2000.00, '2018-01-01', 'Ada', 'Lovelace', '2018-12-31');
insert into policy values (10003, 1000.00, '2018-01-01', 'Alan', 'Turing', '2018-12-31');
insert into policy values (10004, 2000.00, '2017-01-01', 'Rufus', 'Firefly', '2018-12-31');
insert into policy values (10005, 2000.00, '2009-01-01', 'Rick', 'Sanchez', '2018-12-31');
insert into policy values (10006, 1337.00, '1998-01-01', 'Thomas', 'Anderson', '2018-12-31');
insert into policy values (10007, 1337.00, '1994-01-01', 'Zero', 'Cool', '2018-12-31');